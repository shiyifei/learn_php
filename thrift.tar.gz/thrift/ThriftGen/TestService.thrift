namespace php HelloThrift
service TestService
{
    string getStr(1:i32 type)
}
