<?php
namespace HelloThrift\php;
error_reporting(E_ALL);
require_once __DIR__.'/PHP/Thrift/ClassLoader/ThriftClassLoader.php';
use Thrift\ClassLoader\ThriftClassLoader;
$GEN_DIR = __DIR__.'/ThriftGen/gen_php';
$loader = new ThriftClassLoader();
$loader->registerNamespace('Thrift', __DIR__ . '/PHP');
$loader->registerDefinition('HelloThrift', $GEN_DIR);
$loader->register();
if (php_sapi_name() == 'cli') {
  ini_set("display_errors", "stderr");
}

use Thrift\Protocol\TBinaryProtocol;
use Thrift\Transport\TPhpStream;
use Thrift\Transport\TBufferedTransport;
use Thrift\TMultiplexedProcessor;

class TestServiceHandler implements \HelloThrift\TestServiceIf 
{
    public function getStr($type)
    {
       $result = 'what are you doing now';
       switch($type) {
       	case 0:
       		$result = '1111';
       		break;
       	case 1:
       		$result = '2222';
       		break;
       }
       return $result;
    }
}

header('Content-Type', 'application/x-thrift');
if (php_sapi_name() == 'cli') {
  echo "\n";
}
$a = new TPhpStream(TPhpStream::MODE_R | TPhpStream::MODE_W);
$transport = new TBufferedTransport($a);
$protocol = new TBinaryProtocol($transport, true, true);
$tMultiplexedProcessor = new TMultiplexedProcessor();
$testService = new TestServiceHandler();
$testServiceProcessor = new \HelloThrift\TestServiceProcessor($testService);
$tMultiplexedProcessor->registerProcessor('testService', $testServiceProcessor);
$transport->open();
$tMultiplexedProcessor->process($protocol, $protocol);
$transport->close();


