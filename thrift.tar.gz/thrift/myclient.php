<?php

namespace HelloThrift\php;
error_reporting(E_ALL);
require_once __DIR__.'/PHP/Thrift/ClassLoader/ThriftClassLoader.php';

use Thrift\ClassLoader\ThriftClassLoader;

$GEN_DIR = __DIR__.'/ThriftGen/gen_php';
$loader = new ThriftClassLoader();
$loader->registerNamespace('Thrift', __DIR__ . '/PHP');
$loader->registerDefinition('HelloThrift', $GEN_DIR);
$loader->register();

use Thrift\Protocol\TBinaryProtocol;
use Thrift\Protocol\TMultiplexedProtocol;
use Thrift\Transport\THttpClient;
use Thrift\Transport\TBufferedTransport;
use Thrift\Exception\TException;

try {
  $socket = new THttpClient('localhost', 80, '/thrift/myserver.php');
  $transport = new TBufferedTransport($socket);
  $protocol = new TBinaryProtocol($transport);
  $testProtocol = new TMultiplexedProtocol($protocol, 'testService');

  $testService = new \HelloThrift\TestServiceClient($testProtocol);
  $result = $testService->getStr(1);
  var_dump($result);

  $transport->close();
  
} catch (Thrift\Exception\TException $tx) {
  print 'TException: '.$tx->getMessage()."\n";
}

